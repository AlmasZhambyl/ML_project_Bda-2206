# Spine > 2022-08-03 9:59pm
https://universe.roboflow.com/s-sehsr/spine-wgbd7

Provided by a Roboflow user
License: CC BY 4.0

